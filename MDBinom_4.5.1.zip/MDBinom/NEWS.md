# v.4.5.1 2016-02-22

* Usunięte z repozytorium git:
  * katalog ver 4.4
  * plik arch.zip

Tym samym pozbyłem się całej historii pakietu. W razie potrzeby można będzie ją znaleźć w poprzednich wersjach na GitHub.

* Dodanie 1 do numeru wersji, żeby być zgodnym ze standardem. 
  
# v.4.5 2016-02-22

* buckety_br - dodana wersja z wagami
* usun_konce - dodana wersja z wagami
* wydzielenie pliku bdclassing
* dodanie lub nowa wersja funkcji do pliku bdclassing:
  * przypisz2
  * mapuj
  * polacz_buckety

# Wcześniejsze wersje

Zmiany w poprzednich wersjach pakietu można znaleźć w pliku README.old. 