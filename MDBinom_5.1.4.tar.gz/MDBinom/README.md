# MDBinom
Funkcje do analiz zmiennej dwumianowej

