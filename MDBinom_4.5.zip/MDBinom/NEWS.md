# v.4.5 2016-02-22

* buckety_br - dodana wersja z wagami
* usun_konce - dodana wersja z wagami
* wydzielenie pliku bdclassing
* dodanie lub nowa wersja funkcji do pliku bdclassing:
  * przypisz2
  * mapuj
  * polacz_buckety

# Wcześniejsze wersje

Zmiany w poprzednich wersjach pakietu można znaleźć w pliku README.old. 