pkgname <- "MDBinom"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
options(pager = "console")
library('MDBinom')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("AR_boot")
### * AR_boot

flush(stderr()); flush(stdout())

### Name: AR_boot
### Title: Wylicza rozkład AR(GINI) metodą bootstrap
### Aliases: AR_boot

### ** Examples

## dane do przykładu
n<-100000; #liczba obserwacji w próbie
nb<-100; #liczba prób bootstrap
score<-rnorm(n); #generowanie score
def<-as.numeric(score+rnorm(n)<0) #generowanie defaultów
score<-floor(200*score) #dyskretyzacja wartości score

#liczba unikalnych wartości score
length(unique(score))
#[1] 1362

#czas wykonania
system.time(AR_boot(score, def, nb))
#user  system elapsed
# .41    0.00    1.53

#porównanie z czasem wykonania w przypadku pętli i stadradowej funkcji
#do wyliczania GINI
system.time(
	sapply(1:nb, function(i){
			id<-sample(length(score), replace=TRUE);
			AR(score[id], def[id])[[1]]['AR']
	})
)
# user  system elapsed
#83.66    1.62   92.44



cleanEx()
nameEx("buckety_br")
### * buckety_br

flush(stderr()); flush(stdout())

### Name: buckety_br
### Title: Podział na przedziały.
### Aliases: buckety_br

### ** Examples

x<-rnorm(1000);
y<-(x+rnorm(1000))<0;
buckety_br(x, y, 10);



cleanEx()
nameEx("informacje")
### * informacje

flush(stderr()); flush(stdout())

### Name: informacje
### Title: Rysuje informacje o danych
### Aliases: informacje

### ** Examples

x<-rnorm(100);
y<-(x+rnorm(100))>0;
informacje(x, y, buckets=15, span=0.8, main="", hist_col="blue", type="br", method_bucket="eq_length")



cleanEx()
nameEx("przypisz")
### * przypisz

flush(stderr()); flush(stdout())

### Name: przypisz
### Title: Przypisuje wartość z przedziału
### Aliases: przypisz

### ** Examples

n<-1000;
		x1<-rnorm(n);
		y<-(x1+rnorm(n))<0;

		b<-buckety_br(x1,y,10);
		b$fitted<-b$br;

		y_fitted<-przypisz(x1, b, interpol=FALSE)
		plot(x1, y_fitted)

		y_fitted<-przypisz(x1, b, interpol=TRUE)
		plot(x1, y_fitted)



cleanEx()
nameEx("reg_nieparam")
### * reg_nieparam

flush(stderr()); flush(stdout())

### Name: reg_nieparam
### Title: Rysuje lokalnie wygładzoną funckję.
### Aliases: reg_nieparam

### ** Examples

n<-1000;
		x1<-rnorm(n);
		x2<-x1+rnorm(n);
		y<-(x1+rnorm(n))<0;

		reg_nieparam(x1,y, buckets=20)
		reg_nieparam(x2,y, buckets=20, new=FALSE, col_line="green",col_points="green")



cleanEx()
nameEx("usun_konce")
### * usun_konce

flush(stderr()); flush(stdout())

### Name: usun_konce
### Title: Usuwa krańcowe wartości.
### Aliases: usun_konce

### ** Examples

x<-sort(rnorm(10));
x
usun<-usun_konce(x, prob=0.01);
x[-usun]

#usuwa tylko obserwację z prawego krańca
x2<-c(rep(min(x),5),x[5:10])
x2
usun<-usun_konce(x2, prob=0.01);
x2[-usun]



### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
