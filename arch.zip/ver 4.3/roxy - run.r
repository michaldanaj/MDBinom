setwd('C:\\Michal\\pakiety R\\MDBinom\\ver 4.3\\');

library(roxygen)

system('cp -f MDBinom_2012-04-03.r MDBinom.r');
package.skeleton('MDBinom', code_files='MDBinom.R', force=TRUE)

 # `R CMD roxygen -d helloRoxygen' works, too.
roxygenize('MDBinom', roxygen.dir='MDBinom', copy.package=FALSE, unlink.target=FALSE)

system('rmdir MDBinom/inst/*');
system('rmdir MDBinom/inst');
system('cp DESCRIPTION MDBinom/DESCRIPTION');
#system('cp NAMESPACE MDBinom/NAMESPACE');
system('R CMD check  MDBinom')
system('R CMD build -binary  MDBinom')


remove.packages('MDBinom');
install.packages(repos=NULL, lib.loc=getwd(), pkgs="MDBinom_4.3.zip")
library(MDBinom)
help(AR_boot)
