# 2009-05-13
#	  + W funkcji AR doda�em usuwanie przedzia��w, w kt�rych nie ma obserwacji
#	  + Zmieni�em funkcj� buckety_br na now� wersj�. Star� nazwa�em buckety_br_old
#	  + Usun��em funkcj� wygladz
#
# 2009-05-16
#   + Doda�em wymagalno�� biblioteki locfit w funkcj reg_nieparam
#   + Doda�em objekt kalibracja i funkcje na nim dzia�aj�ce      
#   + Doda�em funkcj� hist_wiele
#
# 2009-05-17
#   + W niekt�rych funkcjach dodanie usuwania nieu�ywanych leveli factor�w
#   + Dodanie funkcji infomacje_kal
#
# 2009-05-19
#   + Dodanie parametru ylim2 do funkcji informacje_kal i zabezpieczenie si� 
#     przed warto�ciami nullowymi w zakresie do ylim     
#
# 2009-05-22
#		+ Usuwanie NA i NAN w hist_wiele
# 
# 2009-05--23
#		+ Zmiana domy�lnej warto�ci parametru wytnij w funkcji reg_nieparam
#		  z 0.01 na 0
#		+ Usun��em tworzenie data.frame ze zmiennej score. Jest to niepotrzebne,
#			poza tym przy do.call powodowda�o jaki� b��d przy wywo�aniu z funkcji by().
#
# 2009-06-02
#   + Dodanie odchylenia standardowego do wyniku funkcji buckety_stat
#
#	2009-06-09
#		+ W funkcji reg_nieparam, rysowanie k�ek z powierzchni� proporcjonaln�
#			do ilo�� obserwacji w buckecie
#		+ Dodanie do funkcji reg_nieparam parametru index, kt�ry powoduje, �e na
#			osi x odk�adane s� numery bucket�w, a nie warto�ci zmiennej
#		+ W funkcji buckety_br dodanie sortowania kra�c�w przedzia��w.
#
# 2009-06-14
#		+ Nowa wersja funkcji usun_konce, ca�kiem zmieniona
#		+ Dodanie parametru "target" do funkcji reg_nieparama, umo�liwiaj�cego rysowanie logit�w
#		+	Dodanie funkcji logit. Szczeg�lnie przydatne, gdy mamy d�ugi argument
#
# 2009-06-14
#   + Poprawa funkcji logit. Dodanie logarytmu :).
#
# 2009-09-21
#   + Usuni�cie funkcji kalibracyjnych.
#		+ Usuni�cie funkcji lag
#
# 2009-11-02
#   + Usuni�cie funkcji lag spowodowa�o b��d w funkcjach AR i AR_quick,
#		  kt�re z niej korzysta�y. B��d zosta� poprawiony.
#
# 2009-12-27
#   + Usun��em funkcje drzewo, drzewo_podzial, AR_quick, vec_stats
#		+ W kt�rym� momencie, nie wiem czemu, przerobi�em funkcj� AR, �eby nie dzia�a�a
#			na li�cie score'�w. Przer�bka spowodowa�a nieporawne dzia�anie rysowania.
#			Teraz to poprawi�em.

#' R�ne dzia�ania na zmiennych dwumianowych.
#'
#' \tabular{ll}{
#' Package: \tab binom\cr
#' Type: \tab Package\cr
#' Version: \tab 3.0\cr
#' Date: \tab 2009-12-27\cr
#' License: \tab GPL (>= 2)\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' R�ne dzia�ania na zmiennych dwumianowych
#'
#' @name binom-package
#' @aliases binom
#' @docType package
#' @title R�ne dzia�ania na zmiennych dwumianowych
#' @author Micha� Danaj \email{michal.danaj@@gmail.com}
#' @keywords package
library(roxygen);
roxygen();


#' Liczy logit
#'
#' Liczy logit
#' @param p warto��.
#' @author Micha� Danaj
logit<-function(p)
	return(log(p/(1-p)));
	

#' Liczy Accuracy Ratio (GINI)
#'
#'  Wylicza Accuracy Ratio (GINI). Wynikiem jest \code{data.frame} przechowuj�cy
#'  informacje pozwalaj�ce na wyrysowanie krzywej CAP. W ostatniej kolumnie zapiasna
#'  jest warto�� AR.
#'
#'  @param score_wiele \code{data.frame, vector} b�d� \code{matrix}, zawieraj�ce
#'		 									warto�ci, wed�ug kt�ry nale�y posortowa� warto�ci \code{def}
#'  @param def Wektor warto�ci \code{\{0,1\}} 
#'  @param plot Czy narysowa� krzyw� CAP. Domy�lnie \code{FALSE}. 
#'  @param discrete Czy \code{score_wiele} jest zmienn� dyskretn�. 
#'  @param prob Punkty z przedzia�u \code{[0,1]}, w kt�rym maj� zosta� wyliczone warto�ci. 
#'	@param label Opis stosowany do legendy.
#'
#'	@return Zwraca list� obiekt�w \code{data.frame}. Elementy tej listy odpowiadaj� kolejnym
#'	kolumnom ze \code{score_wiele} i maj� takie same nazwy, jak kolumny ze \code{score_wiele}.
#'	Ka�dy element listy ma posta�:
#'	  \item{do }{G�rna granica przedzia�u, dla kt�rego podane s� statystyki.}
#'	  \item{bad}{Liczba bad-�w w przedziale.}
#'	  \item{obs}{Liczba obserwacji w przedziale.}
#'	  \item{pct_all}{Procentowy udzia� obserwacji w danym przedziale.}
#'	  \item{pct_bad}{Procentowy udzia� bad-�w w danym przedziale w stosunku do 
#'										wszystkich bad-�w.}
#'	  \item{pct_good}{Procentowy udzia� good-�w w danym przedziale w stosunku do 
#'										wszystkich good-�w.}
#'	  \item{br}{Stosunek bad-�w do good-�w w danym przedziale (bad rate).}
#'	  \item{AR}{Wyliczone Accuracy Ratio.}							
#'
#' @author Micha� Danaj
#' @examples
#'	n<-1000;
#'	x<-rnorm(n);
#'	def<- as.numeric(x+rnorm(n)<0);
#'	AR(x,def,plot=TRUE);
AR<-function(score, def, plot=FALSE, return.table=FALSE, 
									sort.order=NULL, label="", ...)
{
	
	if (is.null(score))
		stop("Zmienna 'score' musi by� r�na od NULL!");
	if (is.null(def))
		stop("Zmienna 'def' musi by� r�na od NULL!");

	#sprawdzam, czy def jest z zakresu [0,1]
	if (min(def)<0 || max(def)>1) 
		stop("Zmienna 'def' musi by� z zakresu [0,1].");
		
	sort.order<-match.arg(sort.order);

	def_all<-sum(def);
	obs_all<-length(def);
	good_all<-obs_all-def_all;


	if (plot){
		plot(c(0,1), c(0,1), type="l", lty=1, col=1, xlab="", ylab="",...);
		lines(c(0,def_all/obs_all,1),c(0,1,1), col=1);
	}

		bad<-tapply(def,score,sum);
		obs<-as.vector(table(score));	

		#usuwam score'y, gdzie nie ma obserwacji
		bad<-bad[obs!=0]
		obs<-obs[obs!=0]

		br=bad/obs;
		
		if (!is.null(sort.order) && sort.order=="br")
		{
			k<-order(br, decreasing =TRUE);
			bad<-bad[k];
			obs<-obs[k];
			br<-br[k];
		}
		
		pct_all<-obs/obs_all;
		pct_bad<-bad/def_all;
		pct_good<-(obs-bad)/good_all;
		
		cum_pct_obs<-cumsum(pct_all);
		cum_pct_bad<-cumsum(pct_bad);
		cum_pct_good<-cumsum(pct_good);
										 
		#bior� poprzedni element
		cum_pct_bad_prev<-c(0,cum_pct_bad[2:length(cum_pct_bad)-1])
		cum_pct_obs_prev<-c(0,cum_pct_obs[2:length(cum_pct_obs)-1])

		#licze kawalki powierzchni
		AUC_part<-(cum_pct_obs-cum_pct_obs_prev)*(cum_pct_bad+cum_pct_bad_prev)/2;

		#sumuje cala powierzchnie
		AUC<-sum(AUC_part);
			
		#uwzgledniam bad rate w probce
		#ARt[i]<-(2*AUC-1)/(1-def_all/obs_all);
		ARt<-(2*AUC-1)/(1-def_all/obs_all);
		KS<-max(abs(cum_pct_bad-cum_pct_good));
		IV<-sum((pct_good-pct_bad)*log(pct_good/pct_bad));
		
		if (return.table==TRUE)
			wynik<-list(table=data.frame(bad, obs,pct_all, 
						 pct_bad, pct_good, cum_pct_obs, cum_pct_bad, cum_pct_good,
						 br), stats=c(bad=def_all, good=good_all, obs=obs_all, br=def_all/obs_all, AR=ARt, KS=KS, IV=IV),
	 					 label=label)
	 	else
			wynik<-list(stats=c(bad=def_all, good=good_all, obs=obs_all, br=def_all/obs_all, AR=ARt, KS=KS, IV=IV),
							label=label);

		#names(wynik)[match("nowy",names(wynik))]=names(score)[i];
		if (plot)
			lines(c(0,cum_pct_obs), c(0,cum_pct_bad), type="l", lty=1);
	#}
	#kolej<-order(ARt);
	ARt=round(ARt*100,2);
	if (plot)
		#legend(1,0,paste(names(score)[kolej], " (", ARt[kolej], "%)", sep="" ),lty=1, 
		#	 col=kolej+1, cex=0.8, xjust=1, yjust=0 );
		 legend(1,0,paste(label, " (", ARt, "%)", sep="" ),lty=1, 
			 cex=0.8, xjust=1, yjust=0 );

	class(wynik)<-"AR";
	return(wynik);
}

#' Wy�wietla statystyki przechowywane w obiekcie \code{\link{AR}}
#' 
#' Wy�wietla statystyki przechowywane w obiekcie \code{\link{AR}}
#' @method print AR
print.AR<-function(x){
	print(x$label);
	print(x$stat);
	if (!is.null(x$table))
		print(x$table);
}

#' Wy�wietla statystyki przechowywane w obiekcie \code{\link{AR}}
#' 
#' Wy�wietla statystyki przechowywane w obiekcie \code{\link{AR}}
#' @method HTML AR
HTML.AR<-function(x){
	HTML(x$label);
	HTML(x$stat);
	if (!is.null(x$table))
		HTML(x$table);	
}

#' Zwraca statystyki przechowywane w obiekcie \code{\link{AR}}
#' 
#' Zwraca statystyki przechowywane w obiekcie \code{\link{AR}}
#' @title Zwraca statystyki przechowywane w obiekcie AR
getStats.AR<-function(x){
 s<-t(as.data.frame(x$stats))
 cbind(data.frame(label=x$label),s);
}



#' Przekszta�ca obiekt na \code{\link{data.frame}}
#' 
#' Przekszta�ca obiekt na \code{\link{data.frame}}
#' @title Przekszta�ca obiekt na data.frame 
#' @method as.data.frame AR   
as.data.frame.AR<-function(x){
 s<-t(as.data.frame(x$stats))
 cbind(data.frame(label=x$label),s);	
}



#'  Dzieli na przedzia�y jedn� z dw�ch metod i wylicza na nich bad rate.
#'
#'  Jako �e jest to wersja przej�ciowa, nie ma �adnych detali.
#'  Mo�e poza tym, �e je�li nie ma obserwacji w jakim� bukcecie, to go usuwa.
#'
#'	@title Podzia� na przedzia�y. 
#'
#'  @param x  Zmienna, kt�r� b�dziemy dyskretyzowa�.  
#'  @param y  Zmienna dwumianowa.  
#'  @param n  Liczba wynikowych przedzia��w.  
#'  @param method  Spos�b podzia�u na przedzia�y. Szczeg�y w sekcji Details.  
#'  @param one.value.action Jeszcze nie dzia�a.
#'  @return  
#'  Zwraca \code{data.frame}, w kt�rym dla \code{i}-tego wiersza podane s� statystyki
#'  dla \code{i}-tego przedzia�u.
#'  \item{nr }{Numer przedzia�u.}
#'  \item{od }{Pocz�tek przedzia�u.}
#'  \item{srodek}{�rodek przedzia�u.}
#'  \item{mean}{�rednia z obserwacji w przedziale.}
#'  \item{do}{Koniec przedzia�u.}
#'  \item{n_default}{Liczba default�w.}
#'  \item{n_obs}{Liczba obserwacji.}
#'  \item{br}{Bad rate.}
#'  \item{logit}{Logit.}
#'  \item{probit}{Probit.}
#'  \item{var}{Wariancja zmiennej \code{default}.}
#'  \item{waga}{Waga jako odwrotno�� warinacji. Gdy \code{n_default=0} to przyjmuje si�,
#'			�e \code{n_default=0.5}}
#' @examples 
#' x<-rnorm(1000);
#' y<-(x+rnorm(1000))<0;
#' buckety_br(x, y, 10);
#' @author Micha� Danaj
buckety_br<-function(x, y, n, method=c("eq_length", "eq_count"), one.value.action=c("none","combine"))
{                                         
#	TODO - domy�lna warto�� method
	method<-match.arg(method);

	#dolny kraniec bucketa (wartosc x)
	od=c(1:n);
	#gorny kranieb bucketa (wartosc x)
	do=c(1:n);
	
	if (method=="eq_length")
		granice<-seq(min(x),max(x),length.out=n+1)
	else
		granice<-as.vector(unique(quantile(x, prob=0:n/n, type=1)));

	#oznaczam, do ktorego przedzialu nalezy dana obserwacja
	przedzial<-findInterval(x, granice, rightmost.closed = TRUE, all.inside = TRUE);
	
	#i licze potrzebne rzeczy
	od<-granice[1:(length(granice)-1)];
	do<-granice[2:length(granice)];		

	srodek<-as.vector(tapply(x, przedzial, median));

	mean<-as.vector(tapply(x, przedzial, mean));
	n_obs<- as.vector(tapply(x, przedzial, length));
	n_default<- as.vector(tapply(y, przedzial, sum));
	br<- as.vector(tapply(y, przedzial, mean));
	logit<-log(br/(1-br));
	probit<-qnorm(br);

	zostaw<-sort(unique(przedzial));
	
	as.data.frame(cbind(nr=zostaw,  od=od[zostaw], do=do[zostaw], 
								srodek, mean,  n_default, n_obs, br, logit, probit, var=br*(1-br)/n_obs))
}


#' Wylicza statystyki dla podanych przedzia��w
#'
#' Wylicza statystyki dla podanych przedzia��w 
#' @title Wylicza statystyki dla podanych przedzia��w
#' @usage buckety_stat(bucket, default, total=TRUE)
#'  buckety_stat_wtd(bucket, default, weights=rep(1,length(bucket)), total=TRUE)
#' @aliases buckety_stat buckety_stat_wtd
#' @param bucket wektor z identyfikatorami bucket�w.
#' @param default wektor zmiennych 0,1.
#' @param weights wagi.
#' 
#' @return
#'   Zwraca \code{data.frame}, w kt�rym dla \code{i}-tego wiersza podane s� statystyki
#'   dla \code{i}-tego przedzia�u.
#'   \item{nr }{Numer przedzia�u.}
#'   \item{od }{Pocz�tek przedzia�u.}
#'   \item{srodek}{�rodek przedzia�u.}
#'   \item{mean}{�rednia z obserwacji w przedziale.}
#'   \item{do}{Koniec przedzia�u.}
#'   \item{n_default}{Liczba default�w.}
#'   \item{n_obs}{Liczba obserwacji.}
#'   \item{br}{Bad rate.}
#'   \item{logit}{Logit.}
#'   \item{probit}{Probit.}
#'   \item{var}{Wariancja zmiennej \code{default}.}
#'   \item{waga}{Waga jako odwrotno�� warinacji. Gdy \code{n_default=0} to przyjmuje si�,
#' 			�e \code{n_default=0.5}}
#' @author Micha� Danaj 
buckety_stat<-function(bucket, default, total=TRUE)
 {
		
	#usuwam puste levele factor�w
	if (is.factor(bucket))
		bucket<-factor(bucket);	
		
	obs<- table(bucket);
	obs_all<-sum(obs);
	bad<- as.vector(tapply(default, bucket, sum));
	bad_all<-sum(bad);
	br<- as.vector(tapply(default, bucket, mean));
	std_dev<-as.vector(tapply(default, bucket, sd));
	logit<-log(br/(1-br));                       
	probit<-qnorm(br);

	waga<-NA;
	
	pct_good=(obs-bad)/(obs_all-bad_all);
	pct_bad=bad/bad_all;
	woe=log(pct_good/pct_bad)
	
	wynik<-as.data.frame(cbind( nr=1:length(obs),  
											 n_good=(obs-bad), pct_good,
									     n_bad=bad, pct_bad, 
											 n_obs=obs, pct_obs=obs/obs_all,
											 gb_odds=(obs-bad)/bad,
										   br, std_dev, woe, logit, probit, var=br*(1-br)/obs, waga))
										   
  rownames(wynik)<-sort(unique(bucket));
  
	if (total) {
			wynik<-rbind(wynik, TOTAL=c(length(obs)+1, obs_all-bad_all, 1, bad_all, 1, obs_all,1, 
														(obs_all-bad_all)/bad_all, bad_all/obs_all, sd(default), 0, NA, NA, NA, NA));
  }
	return(wynik);
}

buckety_stat_wtd<-function(bucket, default, weights=rep(1,length(bucket)), total=TRUE)
{

#	dane<-as.data.frame(cbind(score, default));

	#usuwam puste levele factor�w
	if (is.factor(bucket))
		bucket<-factor(bucket);

	obs<- wtd.table(bucket, weights=weights);
	obs_all<-sum(weights);
	bad<- as.vector(tapply(default, bucket, wtd.sum, weights=weights));
	bad_all<-wtd.sum(bad, weights=weights);
	br<- as.vector(tapply(default, bucket, wtd.mean, , weights=weights));
	std_dev<-sqrt(as.vector(tapply(default, bucket, wtd.var, weights=weights)));
	logit<-log(br/(1-br));
	probit<-qnorm(br);

	#do_wagi<-bad;
	#do_wagi[do_wagi==0]<-0.5;
	#do_wagi[do_wagi==obs]<-obs[do_wagi==obs]-0.5;
	#waga<-obs/((do_wagi)/(obs)*(1-(do_wagi)/(obs)));
	waga<-NA;

	pct_good=(obs-bad)/(obs_all-bad_all);
	pct_bad=bad/bad_all;
	woe=log(pct_good/pct_bad)

	wynik<-as.data.frame(cbind( nr=1:length(obs),
											 n_good=(obs-bad), pct_good,
									     n_bad=bad, pct_bad,
											 n_obs=obs, pct_obs=obs/obs_all,
											 gb_odds=(obs-bad)/bad,
										   br, std_dev, woe, logit, probit, var=br*(1-br)/obs, waga))

  rownames(wynik)<-sort(unique(bucket));

	if (total) {
			wynik<-rbind(wynik, TOTAL=c(length(obs)+1, obs_all-bad_all, 1, bad_all, 1, obs_all,1,
														(obs_all-bad_all)/bad_all, bad_all/obs_all, sd(default), 0, NA, NA, NA, NA));
  }
	return(wynik);
}

#' Rysuje informacje o danych
#'
#'  Rysuje histogram zmiennej \code{score}, dla ka�dego przedzia�u histogramu
#'  rysuje bad rate, oraz rysuj� krzyw� regresji dla \code{default~score}. Pod
#'  wykresem wy�wietla informacje o Accuracy Ratios i bad rate.
#' @param score Wektor ze zmienn� numeryczn�. 
#' @param default Wektor ze zmienn� dwumianow�. 
#' @param buckets Sugerowana liczba bucket�w. 
#' @param span Wsp�czynnik wyg�adzaj�cy, wykorzystywany przez funkcj� \code\link{locfit}
#' @param main Tytu� wykresu. 
#' @param hist_col Kolor histogramu 
#' @param ylab Label
#' @param xlab Label
#' @author Micha� Danaj
#' @examples
#' x<-rnorm(100);
#' y<-(x+rnorm(100))>0;
#' informacje(x, y, buckets=15, span=0.8, main="", hist_col="blue", type="br", method_bucket="eq_length")
informacje<-function(score, default, buckets=20, span=0.8, main="", hist_col="blue", method_bucket="eq_length",
				ylab=c("Frequency", "BR"),xlab="Calibrated score", ...)
{	
	def_par=par(no.readonly=TRUE);
	start_par<-par();

	par(mar=c(5,4,4,5)); # Leave space for z axis
	
	h<-hist(score, plot=FALSE);
#	w<-wygladz(score, default, buckets=buckets, span=span, type=type,  plot=FALSE, method_bucket=method_bucket);
	if (length(unique(default))==2)
		local<- locfit(default ~ lp(score, nn=span), family="binomial", link="logit")
	else
		local<- locfit(default ~ lp(score, nn=span)) 
	br2<-predict(local,newdata=h$mid, type="response");                                                                   
	cut_<-cut(score, breaks=h$breaks);
	br<-tapply(default, cut_, mean);
	XRange <- range( c(h[["break"]], h$mid) );
	print(XRange)
	plot(h, col=hist_col ,axes=FALSE, ann=FALSE, ylab="", main=main, xlim=XRange, xlab="faafa");
	print(paste("----",par(no.readonly=TRUE)$usr))
	# Now draw x axis 
	par(new=TRUE);
	axis(1, col = "black") 

	# Now draw y axis 
	par(new=TRUE);
	axis(2, col = hist_col) 

	# Now draw y axis label
	par(new=TRUE);
	mtext(side = 2, text = ylab[1], line = 3, col="black") 

	# Use axTicks() to get default tick locations
	#par(new=TRUE);
	#at = axTicks(2)
	#mtext(side = 2, text = at, at = at, col = "black", line = 1)

	par(new=TRUE)
	YRange <- range( c(br, br2) );
	print(YRange)
	plot(h$mid, br, type="p", axes=FALSE, ylab="", xlab="", bty="n", pch=16, xlim=XRange, ylim=YRange);

	par(new=TRUE)
	plot(h$mid, br2, type="l", axes=FALSE, ylab="", xlab="", bty="n", xlim=XRange, ylim=YRange);

	par(new=TRUE);
	axis(4, at=pretty(YRange))

	par(new=TRUE);
	mtext(ylab[2], 4, 3) 

	par(new=TRUE);
	#print(score[1:10])
	#print(default[1:10])
	
	#AR_value<- AR(score, default, plot=FALSE)[[1]]$stats["AR"]
	#print(AR_value);
  mtext( xlab , 1, line=3);	
	#mtext( paste("AR = ", round(AR_value*100,2), "%;   BR = ",round(mean(default)*100,digits=2),"%" ), 1, 5, col="darkgreen");

	#wracam do wej�ciowych ustawie� parametr�w, ale pozostawiam koordynaty,
	#�eby mo�na by�o �atwo dodawa� co� do wykresu.s
	user<-par(no.readonly=TRUE)$usr;
	par(def_par);
	par(usr=user);
}

informacje_kal<-function(score, default, estym, buckets=20, span=0.8, hist_col="blue", method_bucket="eq_length",
				ylab=c("Frequency", "BR"),xlab="Calibrated score", legx=0, legy=0, legcex=1, ylim2=NULL, ...)
{	
	def_par=par(no.readonly=TRUE);
	start_par<-par();

	par(mar=c(5,4,4,5)); # Leave space for z axis
	
	h<-hist(score, plot=FALSE);
#	w<-wygladz(score, default, buckets=buckets, span=span, type=type,  plot=FALSE, method_bucket=method_bucket);
	if (length(unique(default))==2)
		local<- locfit(default ~ lp(score, nn=span), family="binomial", link="logit")
	else
		local<- locfit(default ~ lp(score, nn=span)) 
	br2<-predict(local,newdata=h$mid, type="response");                                                                   
	cut_<-cut(score, breaks=h$breaks);
	br<-tapply(default, cut_, mean);
	XRange <- range( c(h[["break"]], h$mid) );
	print(XRange)
	plot(h, col=hist_col ,axes=FALSE, ann=FALSE, ylab="", xlim=XRange,...);
	print(paste("----",par(no.readonly=TRUE)$usr))
	# Now draw x axis 
	par(new=TRUE);
	axis(1, col = "black") 

	# Now draw y axis 
	par(new=TRUE);
	axis(2, col = hist_col) 

	# Now draw y axis label
	par(new=TRUE);
	mtext(side = 2, text = ylab[1], line = 3, col="black") 

	# Use axTicks() to get default tick locations
	#par(new=TRUE);
	#at = axTicks(2)
	#mtext(side = 2, text = at, at = at, col = "black", line = 1)

	par(new=TRUE)
	if (is.null(ylim2))	{
		zakr<-c(br,br2,estym);
		zakr<-zakr[!is.na(zakr)];
		YRange <- range( zakr );		
	}
	else
		YRange<-ylim2;
		
	print(YRange)
	plot(h$mid, br, type="p", axes=FALSE, ylab="", xlab="", bty="n", pch=16, xlim=XRange, ylim=YRange);

	par(new=TRUE)
	plot(h$mid, br2, type="l", axes=FALSE, ylab="", xlab="", bty="n", xlim=XRange, ylim=YRange);

	par(new=TRUE);
	axis(4, at=pretty(YRange))

	par(new=TRUE);
	mtext(ylab[2], 4, 3) 

	par(new=TRUE);
	#print(score[1:10])
	#print(default[1:10])
	
	#AR_value<- AR(score, default, plot=FALSE)[[1]]$stats["AR"]
	#print(AR_value);
  mtext( xlab , 1, line=3);	
	#mtext( paste("AR = ", round(AR_value*100,2), "%;   BR = ",round(mean(default)*100,digits=2),"%" ), 1, 5, col="darkgreen");

kolej<-order(score)
par(new=TRUE)
plot(score[kolej], estym[kolej], col="green", lty="dashed", , type="l", axes=FALSE, ylab="", xlab="", bty="n", xlim=XRange, ylim=YRange,...)

#title(main="Calibration")
legend(legx,legy, legend=c("Observations frequency", "Average LGD", "Smoothed average LGD", "Expected LGD"),
				col=c("blue","black","black","green"), lty=c("blank","blank","solid","dashed"),
				pch=c(22,19,NA,NA),	bg=c(NA, "blue","black"), cex=legcex)
	par(def_par);

}


#' Dla obiektu zwr�conego przez funkcj� \code{\link{AR}} rysuje krzyw� ROC lub CAP.
#'
#' Dla obiektu zwr�conego przez funkcj� \code{\link{AR}} rysuje krzyw� ROC lub CAP.
#' @title Rysuje krzywe ROC i CAP 
#' @param ar Obiekt klasy XYZ. 
#' @param plot_type Typ wykresu. 
#' @author Micha� Danaj 
#' @examples	
#'	n<-1000;
#'	x1<-rnorm(n);
#'	x2<-x1+rnorm(n);
#'	y<-(x1+rnorm(n))<0;
#'	
#'	ar<-AR(data.frame(x1,x2),y);
#'	plot_AR(ar, plot_type="ROC");
plot_AR<-function(ar, plot_type=c("ROC", "CAP"))
{
	plot_type<-match.arg(plot_type);

	if (class(ar)=="AR")
		ar<-list(ar=ar);
		
	plot(c(0,1), c(0,1), type="l", lty=1, col=1, xlab="", ylab="");
	if (plot_type=="CAP"){
		br<-ar[[1]]$stats["br"];
		lines(c(0,br,1),c(0,1,1), col=1);
	}
	
	AR<-rep(-1,length(ar));
	labels<-rep("",length(ar))
	for (i in 1:length(ar))
	{
		if (plot_type=="CAP")
			lines(c(0,ar[[i]]$table$cum_pct_all), c(0,ar[[i]]$table$cum_pct_bad), type="l", lty=1, col=i+1)
		else
			lines(c(0,ar[[i]]$table$cum_pct_good), c(0,ar[[i]]$table$cum_pct_bad), type="l", lty=1, col=i+1);
		AR[i]<-ar[[i]]$stats["AR"];
		labels[i]<-ar[[i]]$label;
	}
	
	kolej<-order(AR);
	AR<-round(AR*100,2);
		
	legend(1,0,paste(labels[kolej], " (", AR[kolej], "%)", sep="" ),lty=1, 
		 col=kolej+1, cex=0.8, xjust=1, yjust=0 );
}

plot_AR_dev<-function(ar, plot_type=c("ROC", "CAP"),...)
{
	plot_type<-match.arg(plot_type);

	plot(c(0,1), c(0,1), type="l", lty=1, col=1, xlab="", ylab="",...);
	if (plot_type=="CAP"){
		br<-ar[[1]]$stats["br"];
		lines(c(0,br,1),c(0,1,1), col=1);
	}
	AR<-rep(-1,length(ar));
	for (i in 1:length(ar))
	{
		if (plot_type=="CAP")
			lines(c(0,ar[[i]]$table$cum_pct_obs), c(0,ar[[i]]$table$cum_pct_bad), type="l", lty=1, col=i+1)
		else
			lines(c(0,ar[[i]]$table$cum_pct_good), c(0,ar[[i]]$table$cum_pct_bad), type="l", lty=1, col=i+1);
		AR[i]<-ar[[i]]$stats["AR"];
	}
	kolej<-order(AR);
	AR<-round(AR*100,2);

	legend(1,0,paste(names(ar)[kolej], " (", AR[kolej], "%)", sep="" ),lty=1, 
		 col=kolej+1, cex=0.8, xjust=1, yjust=0 );
}

 
#'  Znajduje przedzia� opisany w \code{bucket}, do kt�rego nale�y \code{x} i 
#'  przypisuje warto�� z \code{bucket_fitted}. Ewentualnie wykonuje interpolacj�.
#'
#'  Je�li \code{interpor=TRUE}, wykonuje interpolacj�, kt�rej w�z�ami s� 
#'  �rodki przedzia��w, pomi�dzy kt�rymi le�y \code{x}, a warto�ciami
#'   \code{bucket$fitted} odpowiadaj�ce tym �rodkom.
#' 
#'   @title Przypisuje warto�� z przedzia�u 
#' 
#'   @param x Wektor zmiennych numerycznych. 
#'   @param bucket \code{data.frame} z kolumnami:
#'		\ul{
#' 			\li{od}{Dolny kraniec przedzia�u.}
#' 			\li{do}{G�rny kreniec przedzia�u.}
#' 			\li{srodek}{�rodek przedzia�u.}
#' 			\li{fitted}{Warto�� przypisana do danego przedzia�u.}
#' 		}
#'   @param interpol Czy przeprowadzi� interpolacj�?
#' 
#' @return  Wektor warto�ci.
#' 
#' @author Micha� Danaj
#' 
#' @examples
#' 		n<-1000;
#' 		x1<-rnorm(n);
#' 		y<-(x1+rnorm(n))<0;
#' 		
#' 		b<-buckety_br(x1,y,10);
#' 		b$fitted<-b$br;
#' 		
#' 		y_fitted<-przypisz(x1, b, interpol=FALSE)
#' 		plot(x1, y_fitted)
#' 		
#' 		y_fitted<-przypisz(x1, b, interpol=TRUE)
#' 		plot(x1, y_fitted) 
#' @TODO  BUG! Je�li bucket wiersze nie b�d� posortowane, to b�d� b��dne wyniki,
#' bo p�niej sortujemy i odnosimy si� tym porz�dkiem do pocz�tkowego porz�dku
przypisz<-function(x, bucket, interpol=FALSE)
{

	n<-dim(bucket)[1];

	{		
		if (interpol)
		{
			#obcinam zakresy do wartosci srodkow krancowych przedzialow
			x[x<min(bucket$srodek)]<-min(bucket$srodek);
			x[x>max(bucket$srodek)]<-max(bucket$srodek);

			przedzial<-findInterval(x, bucket$srodek, rightmost.closed = TRUE, all.inside = TRUE);

			od<-bucket$srodek[przedzial];
			do<-bucket$srodek[przedzial+1];
			wynik<-(x-od)/(do-od)*bucket$fitted[przedzial+1]+(do-x)/(do-od)*bucket$fitted[przedzial];
		}
		else
		{
			granice=sort(unique(c(bucket$od, bucket$do)));
			przedzial<-findInterval(x, granice, rightmost.closed = TRUE, all.inside = TRUE);
			wynik<-bucket$fitted[przedzial];
		}
	}	
	wynik
}




#'  Rysuje lokalnie wyg�adzon� funckj�.
#'  
#'  Rysuje i zwraca statystyki dla bucket�w.  
#' @param score Wektor zmiennych numerycznych. 
#' @param default Wektor zmiennej dwumianowej. 
#' @param buckets Liczba bucket�w, na ile nele�y podzieli� \code{score}. 
#' @param wytnij Ile kra�cowych obserwacji wyci��. 
#' @param span Wsp�czynnik wyg�adzania. Szeg�y w funkcji \code{\link{locfit}}
#' @param degree Stopie� wielomianu do lokalnego wyg�adzania. Szeg�y w funkcji \code{\link{locfit}} 
#' @param plot Czy rysowa� wykres. 
#' @param new Czy rysowa� wykres od nowa. 
#' @param col_points Kolor punkt�w. 
#' @param col_line Kolor lini. 
#' @author Micha� Danaj 
#' @examples
#'		n<-1000;
#'		x1<-rnorm(n);
#'		x2<-x1+rnorm(n);
#'		y<-(x1+rnorm(n))<0;
#'		
#'		reg_nieparam(x1,y, buckets=20)
#'		reg_nieparam(x2,y, buckets=20, new=FALSE, col_line="green",col_points="green")
reg_nieparam<-function(score, default, buckets=100, wytnij=0, span=0.7, degree=2, plot=TRUE, target="br",new=TRUE, col_points="black", col_line="darkblue", 
											index=FALSE, ...)
{

	dane<-data.frame(score,default)
	if (wytnij>0)
		dane<-dane[-usun_konce(dane$score, prob=wytnij),];
		
	bucket<-buckety_br(dane$score , dane$default, buckets, method="eq_count");
	if (length(unique(default))==2)
		l<- locfit(default ~ lp(score, nn=span), family="binomial", link="logit", data=dane)
	else
		l<- locfit(default ~ lp(score, nn=span), data=dane) 

	b2<-predict(l, newdata=bucket$srodek);
	if (target=="br")
		bucket2<-cbind(bucket, fitted=b2)
	else
		bucket2<-cbind(bucket, fitted=log(b2/(1-b2)));
		
	skala<-sqrt(bucket$n_obs/(length(score)/buckets));
	
	x<-bucket2$srodek;
	if (index)
		x<-bucket$nr;
	
	if (plot){
		if (new==TRUE)
			plot(x, with(bucket2, get(target)), col=col_points, cex=skala, ...)
		else
			points(x, with(bucket2, get(target)), cex=skala, col=col_points,...);
		lines(x, bucket2$fitted,  col=col_line,...);
	}
	bucket2
}
   
#' Usuwa kra�cowe warto�ci.
#'
#' Zwraca indeksy \code{prob} najmniejszych i \code{prob} najwi�kszych warto�ci. Je�li
#' jednak nie jest mo�liwe ustalenie co najwy�ej \code{prob} obserwacji, nie 
#' zostaje usuni�ta �adna.
#' @param score Wektor warto�ci numerycznych. 
#' @param prob Jak� cz�� obserwacj nale�y usun�� z jednego kra�ca. 
#' @return Zwraca wektor z indeksami element�w, kt�re powinny zosta� usuni�te.
#' @author Micha� Danaj
#' @examples
#' x<-sort(rnorm(10));
#' x
#' usun<-usun_konce(x, prob=0.01);
#' x[-usun]
#'
#' #usuwa tylko obserwacj� z prawego kra�ca
#' x2<-c(rep(min(x),5),x[5:10])
#' x2
#' usun<-usun_konce(x2, prob=0.01);
#' x2[-usun]

usun_konce<-function(score, prob=0.01)
{
	s<-cumsum(table(score)/length(score))
	new_min<- as.numeric(names(which.max(s[s<=prob])))
	if (length(new_min)==0)
		new_min = -.Machine$double.xmax;
	new_max<- as.numeric(names(which.min(s[s>=1-prob])))
	if (length(new_max)==0)
		new_max = .Machine$double.xmax;	
	return( which(score<=new_min | new_max<=score) )
}