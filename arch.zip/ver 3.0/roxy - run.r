setwd('C:\\R\\moje pakiety\\binom\\ver 3.0\\');

library(roxygen)

system('cp -f binom_2009-12-27.r binom.r');
package.skeleton('binom', code_files='binom.R', force=TRUE)

 # `R CMD roxygen -d helloRoxygen' works, too.
roxygenize('binom', roxygen.dir='binom', copy.package=FALSE, unlink.target=FALSE)

system('rmdir binom/inst/*');
system('rmdir binom/inst');
system('cp DESCRIPTION binom/DESCRIPTION');
system('R CMD check  binom')
system('R CMD build -binary  binom')


install.packages(repos=NULL, lib.loc=getwd(), pkgs="binom_3.0.zip")
library(binom)
help(usun_konce)
