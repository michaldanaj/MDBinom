
`AR` <-
function (score_wiele, def, plot = FALSE, discrete = FALSE, prob = c(0:100/100)) 
{
    if (is.vector(score_wiele)) 
        score_wiele <- do.call("data.frame", list(substitute(score_wiele)))
    else score_wiele <- as.data.frame(score_wiele)
    ile_scorow <- ncol(score_wiele)
    nazwa <- ARt <- rep(0, ile_scorow)
    wynik <- list()
    def_all <- sum(def)
    obs_all <- length(def)
    if (plot) {
        plot(c(0, 1), c(0, 1), type = "l", lty = 1, col = 1, 
            xlab = "", ylab = "")
        lines(c(0, def_all/obs_all, 1), c(0, 1, 1), col = 1)
    }
    for (i in 1:ile_scorow) {
        kolej <- order(score_wiele[, i])
        dane <- data.frame(score = score_wiele[, i], def)[kolej, 
            ]
        cum_bad <- cumsum(tapply(dane$def, dane$score, sum))/def_all
        cum_obs <- cumsum(table(dane$score))/obs_all
        cum_bad_prev <- lag(cum_bad, 1, fill = 0)
        cum_obs_prev <- lag(cum_obs, 1, fill = 0)
        AUC_part <- (cum_obs - cum_obs_prev) * (cum_bad + cum_bad_prev)/2
        AUC <- sum(AUC_part)
        ARt[i] <- (2 * AUC - 1)/(1 - def_all/obs_all)
        if (discrete | is.factor(score_wiele[[i]])) {
            do <- as.numeric(names(cum_bad))
            bad <- cum_bad * def_all
            obs <- cum_obs * obs_all
        }
        else {
            granice <- as.vector(quantile(dane$score, prob = prob))
            m_dzies = log10(1/(max(dane$score) - min(dane$score)))
            eps = 12
            m_dzies <- round(m_dzies + eps, 0)
            granice <- unique(round(granice, m_dzies))
            przedzial <- findInterval(dane$score, granice, rightmost.closed = FALSE, 
                all.inside = FALSE)
            granice <- c(granice, max(granice))
            do = granice[unique(przedzial) + 1]
            bad <- cumsum(tapply(dane$def, przedzial, sum))
            obs <- cumsum(tapply(dane$def, przedzial, length))
        }
        wynik$nowy <- list(stats = data.frame(do, bad, obs, pct_all = obs/obs_all, 
            pct_bad = bad/def_all, pct_good = (obs - bad)/(obs_all - 
                def_all), br = bad/obs), AR = ARt[i])
        names(wynik)[match("nowy", names(wynik))] = names(score_wiele)[i]
        if (plot) 
            lines(c(0, cum_obs), c(0, cum_bad), type = "l", lty = 1, 
                col = i + 1)
    }
    kolej <- order(ARt)
    ARt = round(ARt * 100, 2)
    if (plot) 
        legend(1, 0, paste(names(score_wiele)[kolej], " (", ARt[kolej], 
            "%)", sep = ""), lty = 1, col = kolej + 1, cex = 0.8, 
            xjust = 1, yjust = 0)
    wynik
}
`AR_dev` <-
function (score_wiele, def, plot = FALSE, discrete = FALSE, prob = c(0:100/100)) 
{
    if (is.vector(score_wiele)) 
        score_wiele <- do.call("data.frame", list(substitute(score_wiele)))
    else score_wiele <- as.data.frame(score_wiele)
    ile_scorow <- ncol(score_wiele)
    nazwa <- ARt <- rep(0, ile_scorow)
    wynik <- list()
    def_all <- sum(def)
    obs_all <- length(def)
    if (plot) {
        plot(c(0, 1), c(0, 1), type = "l", lty = 1, col = 1, 
            xlab = "", ylab = "")
        lines(c(0, def_all/obs_all, 1), c(0, 1, 1), col = 1)
    }
    for (i in 1:ile_scorow) {
        kolej <- order(score_wiele[, i])
        dane <- data.frame(score = score_wiele[, i], def)[kolej, 
            ]
        cum_bad <- cumsum(tapply(dane$def, dane$score, sum))/def_all
        cum_obs <- cumsum(table(dane$score))/obs_all
        cum_bad_prev <- lag(cum_bad, 1, fill = 0)
        cum_obs_prev <- lag(cum_obs, 1, fill = 0)
        AUC_part <- (cum_obs - cum_obs_prev) * (cum_bad + cum_bad_prev)/2
        AUC <- sum(AUC_part)
        ARt[i] <- (2 * AUC - 1)/(1 - def_all/obs_all)
        if (discrete | is.factor(score_wiele[[i]])) {
            do <- names(cum_bad)
            agr <- dane$score
        }
        else {
            do <- as.vector(unique(quantile(dane$score, prob = prob, 
                type = 1)))
            agr <- findInterval(dane$score, do, rightmost.closed = FALSE, 
                all.inside = FALSE)
        }
        bad <- cumsum(tapply(dane$def, agr, sum))
        obs <- cumsum(tapply(dane$def, agr, length))
        wynik$nowy <- list(stats = data.frame(do, bad, obs, pct_all = obs/obs_all, 
            pct_bad = bad/def_all, pct_good = (obs - bad)/(obs_all - 
                def_all), br = bad/obs), AR = ARt[i])
        names(wynik)[match("nowy", names(wynik))] = names(score_wiele)[i]
        if (plot) 
            lines(c(0, cum_obs), c(0, cum_bad), type = "l", lty = 1, 
                col = i + 1)
    }
    kolej <- order(ARt)
    ARt = round(ARt * 100, 2)
    if (plot) 
        legend(1, 0, paste(names(score_wiele)[kolej], " (", ARt[kolej], 
            "%)", sep = ""), lty = 1, col = kolej + 1, cex = 0.8, 
            xjust = 1, yjust = 0)
    return(wynik)
}
`buckety_br` <-
function (score, default, n, method = c("eq_length", "eq_count"), 
    no.bads.action = c("none", "combine")) 
{
    method <- match.arg(method)
    dane <- as.data.frame(cbind(score, default))
    dane <- dane[order(dane$score), ]
    od = c(1:n)
    do = c(1:n)
    if (method == "eq_length") {
        dane$przedzial <- cut(dane$score, n)
        przedzial <- levels(cut(dane$score, n))
        for (i in 1:length(przedzial)) {
            od[i] = strsplit(przedzial[i], split = ",")[[1]][1]
            od[i] = substr(od[i], 2, nchar(od[i]))
            do[i] = strsplit(przedzial[i], split = ",")[[1]][2]
            do[i] = substr(do[i], 1, nchar(do[i]) - 1)
        }
        od <- as.numeric(od)
        do <- as.numeric(do)
    }
    else {
        perc <- 1:(n + 1)
        for (i in 0:n) perc[i + 1] <- as.vector(quantile(dane$score, 
            prob = i/n))
        granice <- unique(perc)
        granice <- granice[order(granice)]
        dane$przedzial <- findInterval(dane$score, granice, rightmost.closed = TRUE, 
            all.inside = TRUE)
        od <- granice[1:(length(granice) - 1)]
        do <- granice[2:length(granice)]
    }
    srodek <- as.vector(tapply(dane$score, dane$przedzial, median))
    zostaw <- !is.na(srodek)
    srodek <- srodek[zostaw]
    mean <- as.vector(tapply(dane$score, dane$przedzial, mean))[zostaw]
    n_obs <- as.vector(tapply(dane$score, dane$przedzial, length))[zostaw]
    n_default <- as.vector(tapply(dane$default, dane$przedzial, 
        sum))[zostaw]
    br <- as.vector(tapply(dane$default, dane$przedzial, mean))[zostaw]
    logit <- log(br/(1 - br))
    probit <- qnorm(br)
    do_wagi <- n_default
    do_wagi[do_wagi == 0] <- 0.5
    do_wagi[do_wagi == n_obs] <- n_obs[do_wagi == n_obs] - 0.5
    waga <- n_obs/((do_wagi)/(n_obs) * (1 - (do_wagi)/(n_obs)))
    as.data.frame(cbind(nr = (1:length(od))[zostaw], od[zostaw], 
        srodek, mean, do[zostaw], n_default, n_obs, br, logit, 
        probit, var = br * (1 - br)/n_obs, waga))
}
`buckety_br_dev` <-
function (x, y, n, method = c("eq_length", "eq_count"), one.value.action = c("none", 
    "combine")) 
{
    method <- match.arg(method)
    dane <- as.data.frame(cbind(x, y))
    dane <- dane[order(dane$x), ]
    od = c(1:n)
    do = c(1:n)
    if (method == "eq_length") 
        granice <- seq(min(x), max(x), length.out = n + 1)
    else granice <- as.vector(unique(quantile(dane$x, prob = 0:n/n, 
        type = 1)))
    dane$przedzial <- findInterval(dane$x, granice, rightmost.closed = TRUE, 
        all.inside = TRUE)
    od <- granice[1:(length(granice) - 1)]
    do <- granice[2:length(granice)]
    srodek <- as.vector(tapply(dane$x, dane$przedzial, median))
    mean <- as.vector(tapply(dane$x, dane$przedzial, mean))
    n_obs <- as.vector(tapply(dane$x, dane$przedzial, length))
    n_default <- as.vector(tapply(dane$y, dane$przedzial, sum))
    br <- as.vector(tapply(dane$y, dane$przedzial, mean))
    logit <- log(br/(1 - br))
    probit <- qnorm(br)
    zostaw <- unique(dane$przedzial)
    as.data.frame(cbind(nr = zostaw, od = od[zostaw], do = do[zostaw], 
        srodek, mean, n_default, n_obs, br, logit, probit, var = br * 
            (1 - br)/n_obs))
}
`buckety_stat` <-
function (score, default, od, do) 
{
    dane <- as.data.frame(cbind(score, default))
    granice <- unique(c(od, do))
    granice <- granice[order(granice)]
    dane$przedzial <- findInterval(dane$score, granice, rightmost.closed = TRUE, 
        all.inside = TRUE)
    srodek <- as.vector(tapply(dane$score, dane$przedzial, median))
    mean <- as.vector(tapply(dane$score, dane$przedzial, mean))
    n_obs <- as.vector(tapply(dane$score, dane$przedzial, length))
    n_default <- as.vector(tapply(dane$default, dane$przedzial, 
        sum))
    br <- as.vector(tapply(dane$default, dane$przedzial, mean))
    logit <- log(br/(1 - br))
    probit <- qnorm(br)
    do_wagi <- n_default
    do_wagi[do_wagi == 0] <- 0.5
    do_wagi[do_wagi == n_obs] <- n_obs[do_wagi == n_obs] - 0.5
    waga <- n_obs/((do_wagi)/(n_obs) * (1 - (do_wagi)/(n_obs)))
    as.data.frame(cbind(nr = 1:length(od), od, srodek, mean, 
        do, n_default, n_obs, br, logit, probit, var = br * (1 - 
            br)/n_obs, waga))
}
`drzewo` <-
function (score, def, freq = NULL, wytnij = 0.01, min_split = 30, 
    min_bucket = 10, max_gleb = 4, n_buckets = 20, plot = c(TRUE, 
        FALSE)) 
{
    k <- order(score)
    score <- score[k]
    def <- def[k]
    if (is.null(freq)) 
        freq <- rep(1, length(score))
    else {
        stop("poki co nie obslugiwane freq inne od NULL")
        freq <- freq[k]
    }
    if (wytnij > 0) {
        usun <- usun_konce(score, prob = wytnij)
        score <- score[-usun]
        def <- def[-usun]
        freq <- freq[-usun]
    }
    def_a <- tapply(def, score, sum)
    freq_a <- tapply(freq, score, sum)
    score_a <- unique(score)
    w <- drzewo_podzial(score_a, def_a, 1, min(score), max(score), 
        freq_a, 0, min_split, min_bucket, max_gleb)
    w <- w[is.na(w$poprawa), ]
    bucket <- buckety_stat(score, def, w$od, w$do)
    bucket$fitted <- bucket$br
    if (plot) {
        plot(bucket$srodek, bucket$br, xlab = "", ylab = "")
        for (i in 1:length(w$od)) lines(c(bucket$od[i], bucket$do[i]), 
            c(bucket$fitted[i], bucket$fitted[i]), col = "blue")
    }
    bucket
}
`drzewo_podzial` <-
function (score, def, nr_wezla, od, do, freq, glebokosc, min_split = 200, 
    min_bucket = 100, max_gleb = 3) 
{
    all_obs <- sum(freq)
    all_bad <- sum(def)
    br_akt <- all_bad/all_obs
    gini_akt <- br_akt * (1 - br_akt) * all_obs
    wezel <- data.frame(nr_wezla, rodzic = floor(nr_wezla/2), 
        od, do, n_obs = all_obs, n_bad = all_bad, br = br_akt, 
        poprawa = NA, podzial = NA)
    wynik <- wezel
    if (all_obs > min_split) {
        cum_bad_lewo <- cumsum(def)
        cum_obs_lewo <- cumsum(freq)
        cum_bad_prawo <- (all_bad - cum_bad_lewo)
        cum_obs_prawo <- (all_obs - cum_obs_lewo)
        br_lewo <- cum_bad_lewo/cum_obs_lewo
        br_prawo <- cum_bad_prawo/cum_obs_prawo
        gini_lewo <- br_lewo * (1 - br_lewo) * cum_obs_lewo
        gini_prawo <- br_prawo * (1 - br_prawo) * cum_obs_prawo
        gini_roz <- gini_akt - (gini_prawo + gini_lewo)
        zostaw <- (cum_obs_lewo > min_bucket) & (cum_obs_prawo > 
            min_bucket)
        gini_roz[!zostaw] <- NA
        nr <- which.max(gini_roz)
        if (length(nr) > 0 & glebokosc < max_gleb) {
            wezel$poprawa <- gini_roz[nr]
            wezel$podzial <- (score[nr] + score[nr + 1])/2
            l <- length(score)
            wl <- drzewo_podzial(score[1:nr], def[1:nr], nr_wezla * 
                2, od, wezel$podzial, freq[1:nr], glebokosc + 
                1, min_split, min_bucket, max_gleb)
            wr <- drzewo_podzial(score[(nr + 1):l], def[(nr + 
                1):l], nr_wezla * 2 + 1, wezel$podzial, do, freq[(nr + 
                1):l], glebokosc + 1, min_split, min_bucket, 
                max_gleb)
            wynik <- rbind(wezel, wl, wr)
        }
    }
    wynik
}
`informacje` <-
function (score, default, buckets = 20, span = 0.8, main = "", 
    hist_col = "blue", type = "br", method_bucket = "eq_length") 
{
    par(mar = c(7, 4, 4, 5) + 0.1)
    h <- hist(score, plot = FALSE)
    local <- locfit(default ~ lp(score, nn = span), family = "binomial", 
        link = "logit")
    br2 <- predict(local, newdata = h$mid)
    cut_ <- cut(score, breaks = h$breaks)
    br <- tapply(default, cut_, mean)
    XRange <- range(c(h[["break"]], h$mid))
    plot(h, col = hist_col, axes = FALSE, ann = FALSE, ylab = "", 
        main = main, xlim = XRange)
    par(new = T)
    axis(1, col = "black")
    par(new = T)
    axis(2, col = hist_col)
    par(new = T)
    mtext(side = 2, text = "Frequency", line = 3, col = "black")
    par(new = T)
    YRange <- range(c(br, br2))
    plot(h$mid, br, type = "p", axes = F, xlab = "", ylab = "", 
        bty = "n", pch = 16, xlim = XRange, ylim = YRange)
    par(new = T)
    plot(h$mid, br2, type = "l", axes = F, xlab = "", ylab = "", 
        bty = "n", xlim = XRange, ylim = YRange)
    par(new = T)
    axis(4, at = pretty(YRange))
    par(new = T)
    mtext(type, 4, 3)
    par(new = T)
    AR_value <- AR2(score, default, plot = F)
    mtext(paste("AR = ", round(AR_value[[1]]$AR[1] * 100, 2), 
        "%;   BR = ", round(mean(default) * 100, digits = 2), 
        "%"), 1, 5, col = "darkgreen")
}
`lag` <-
function (x, d, fill = NA) 
{
    c(rep(fill, d), x)[1:length(x)]
}
`plot_AR` <-
function (ar, plot_type = c("ROC", "CAP")) 
{
    plot_type <- match.arg(plot_type)
    plot(c(0, 1), c(0, 1), type = "l", lty = 1, col = 1, xlab = "", 
        ylab = "")
    if (plot_type == "CAP") {
        br <- ar[[1]]$br[dim(ar[[1]])[1]]
        lines(c(0, br, 1), c(0, 1, 1), col = 1)
    }
    AR <- rep(-1, length(ar))
    for (i in 1:length(ar)) {
        if (plot_type == "CAP") 
            lines(c(0, ar[[i]]$pct_all), c(0, ar[[i]]$pct_bad), 
                type = "l", lty = 1, col = i + 1)
        else lines(c(0, ar[[i]]$pct_good), c(0, ar[[i]]$pct_bad), 
            type = "l", lty = 1, col = i + 1)
        AR[i] <- ar[[i]]$AR[1]
    }
    kolej <- order(AR)
    AR <- round(AR * 100, 2)
    legend(1, 0, paste(names(ar)[kolej], " (", AR[kolej], "%)", 
        sep = ""), lty = 1, col = kolej + 1, cex = 0.8, xjust = 1, 
        yjust = 0)
}
`przypisz` <-
function (x, bucket, interpol = c(TRUE, FALSE)) 
{
    n <- dim(bucket)[1]
    {
        if (interpol) {
            x[x < min(bucket$srodek)] <- min(bucket$srodek)
            x[x > max(bucket$srodek)] <- max(bucket$srodek)
            przedzial <- findInterval(x, bucket$srodek, rightmost.closed = TRUE, 
                all.inside = TRUE)
            od <- bucket$srodek[przedzial]
            do <- bucket$srodek[przedzial + 1]
            wynik <- (x - od)/(do - od) * bucket$fitted[przedzial + 
                1] + (do - x)/(do - od) * bucket$fitted[przedzial]
        }
        else {
            granice = unique(c(bucket$od, bucket$do))
            przedzial <- findInterval(x, granice, rightmost.closed = TRUE, 
                all.inside = TRUE)
            wynik <- bucket$fitted[przedzial]
        }
    }
    wynik
}
`reg_nieparam` <-
function (score, default, buckets = 100, wytnij = 0.01, span = 0.7, 
    degree = 2, plot = TRUE, new = TRUE, col_points = "black", 
    col_line = "darkblue") 
{
    dane <- data.frame(score, default)
    if (wytnij > 0) 
        dane <- dane[-usun_konce(dane$score, prob = wytnij), 
            ]
    bucket <- buckety_br(dane$score, dane$default, buckets, method = "eq_count")
    l <- locfit(default ~ lp(score, nn = span), family = "binomial", 
        link = "logit", data = dane)
    b2 <- predict(l, newdata = bucket$srodek)
    bucket2 <- cbind(bucket, fitted = b2)
    if (plot) {
        if (new == TRUE) 
            plot(bucket2$srodek, bucket2$br, xlab = "", ylab = "", 
                col = col_points)
        else points(bucket2$srodek, bucket2$br, xlab = "", ylab = "", 
            col = col_points)
        lines(bucket2$srodek, bucket2$fitted, col = col_line)
    }
    bucket2
}
`usun_konce` <-
function (score, prob = 0.01) 
{
    l = quantile(score, prob = prob)
    p = quantile(score, prob = (1 - prob))
    do_usuniecia <- rep(FALSE, times = length(score))
    if (abs(length(score[score <= l]) - length(score) * prob) <= 
        1) 
        do_usuniecia <- (score <= l)
    if (abs(length(score[score >= p]) - length(score) * prob) <= 
        1) 
        do_usuniecia <- do_usuniecia | (score >= p)
    c(1:length(score))[do_usuniecia]
}
`vec_stats` <-
function (x) 
{
    print("Pierwsze 5:")
    print(x[1:5])
    print(table(!is.na(x)))
    print(summary(x))
    srednia <- mean(x, na.rm = T)
    ile <- length(x)
    print(paste("srednia: ", srednia, " dlugosc: ", ile))
    print("Ostatnie 5:")
    print(x[(length(x) - 5):length(x)])
    par(mfrow = c(1, 2))
    hist(x)
    hist(x[quantile(x, prob = 0.03, na.rm = T) < x & x < quantile(x, 
        prob = 0.97, na.rm = T)])
    par(mfrow = c(1, 1))
}
`wygladz` <-
function (score, default, buckets = 50, span = 0.5, type = "logit", 
    plot = TRUE, method_bucket = "eq_count") 
{
    if (buckets > length(score)) 
        print("ERROR: liczba bucketow wieksza, niz liczba obserwacji!")
    dane <- as.data.frame(cbind(score, default))
    dane <- dane[order(dane$score), ]
    bucket <- buckety_br(dane$score, dane$default, buckets, method = method_bucket)
    if (type == "logit") 
        wartosci <- bucket$logit
    else if (type == "probit") 
        wartosci <- bucket$probit
    else if (type == "br") 
        wartosci = bucket$br
    else print("ERROR: blednie podana wartosc zmiennej 'type'")
    zostaw = abs(wartosci) != Inf
    wartosci = wartosci[zostaw]
    local <- locfit(default ~ lp(score, nn = span), family = "binomial", 
        link = "logit")
    b2 <- predict(local, newdata = bucket$srodek[zostaw])
    if (plot) {
        plot(local)
        points(bucket$srodek[zostaw], wartosci)
    }
    wyn <- cbind(bucket$srodek[zostaw], wartosci, b2)
    colnames(wyn) <- c("srodek", "br", "fitted")
    as.data.frame(wyn)
}
