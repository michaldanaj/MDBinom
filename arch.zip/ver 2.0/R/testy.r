load("C:\\r\\wska�niki do szybkiej �cie�ki\\wskazniki dla szybkiej2.RData");

			
x<-1:3/3
y<-c(1,0,0)

f<-factor(x)
levels(f)<-c('a','b','c')

names(tapply(x,f,sum))

AR_dev(x, y)
AR_dev2(x,y)
AR_dev(x, y, discrete=T)
AR_dev(f, y)

c<-levels(f);
AR_dev(c, y)

names(x)

u<-unique(quantile(x,prob=0:3/3, type=1))
u
findInterval(x, u, rightmost.closed = FALSE, all.inside = F);


u<-as.vector(quantile(x,prob=0:3/3, type=1))

prob=1:100/100;
			granice<-as.vector(unique(quantile(x, prob=prob, type=1)));
			
			#ka�dej obserwacji przypisuj� przedzia�, w kt�ry wpad�a			
			przedzial<-findInterval(x, granice, rightmost.closed = FALSE, all.inside = FALSE);
			granice<-c(granice,max(granice));
			do=granice[unique(przedzial)+1];
			bad<-cumsum(tapply(dane$def, przedzial, sum));
			obs<-cumsum(tapply(dane$def, przedzial, length));

findInterval(c(0,1,2,3,4,5,6,7,8,9,10), c(1,5,10), rightmost.closed = T, all.inside = FALSE);


score_wiele=data.frame(s=rat$fprawna)
def=rat$def
plot=FALSE
discrete=FALSE

ar1<-AR_dev(data.frame(s1=rat$fprawna, s2=rat$nr__t), rat$def, prob=0:10/10, discrete=T, plot=T)
ar2<-AR(data.frame(s1=rat$fprawna, s2=rat$nr__t), rat$def, prob=0:10/10, discrete=T, plot=T)
ar3<-AR_dev2(data.frame(s1=rat$fprawna, s2=rat$nr__t), rat$def, plot=T, sort.order=c("b","s"), return.table=T)
		
s<-sample(1:14413,100)									
plot(ar2$s$stats$do[s],ar2$s$stats$br[s])
ar1$s$stats
ar2$s$stats

cbind(ar1$s$stats$pct_all,
ar2$s$stats$pct_all, abs(ar1$s$stats$pct_all-ar2$s$stats$pct_all))

length(as.vector(unique(quantile(rat$nr__t, prob=0:100/100, type=1))))

length(as.vector(quantile(rat$nr__t, prob=0:100/100, type=1)))
abs(ar1$s$stats-ar2$s$stats)<0.00001

par(mfrow=c(1,2));
plot_AR_dev(ar3, main=("To jest wykres"), plot="CAP")
plot_AR_dev(ar3, main=("To jest wykres"), plot="ROC")

buckety_stat(rat$nr__t, rat$def)
buckety_stat(rat$fprawna, rat$def, total=F)
ar<-AR(rat$fprawna, rat$def, return.table=T)
AR(rat$nr__t, rat$def, return.table=T)

reg_nieparam(rat$nr__t, rat$def)

buckety_stat_dev(c(1:10,100,101), rnorm(12)<0.5+0, breaks=c(0,5,11,20,200))


tk2dde.services()

dde.table<-function(table, sheet="Sheet1", rstart=1, cstart=1) {
 	rend=rstart+nrow(table);
 	cend=cstart+ncol(table);
 	
	for (i in 1:ncol(table)) 	
	{
	  w_co<-paste("R", rstart,"C", cstart+i-1,":R",rstart,"C",cstart+i-1,sep="");
  	tk2dde.poke("Excel", sheet, w_co, colnames(table)[i]) 	

	 	w_co<-paste("R", rstart+1,"C", cstart+i-1,":R",rend+1,"C",cstart+i-1,sep="");
	 	gsub("\\.",",",table[,i])
		tk2dde.poke("Excel", sheet, w_co, gsub("\\.",",",table[,i])) 	
	}
}

dde.table(ar3[[1]]$table,rstart=5, cstart=5)

as.character(3)
tk2dde.poke("Excel", "Sheet1", "R1C1:R1C2", c("5.7", "6.34", "4","6"))

tk2dde.poke("Excel", "Sheet1", "R1C2:R1C3", t(c("w", "e")))
s<-'[Select("R1C1:R3C1")]'
tk2dde.exec("Excel", "Sheet1", s)

x<-data.frame(c=c(1,2,3), y=3:5/5);
as.character(x)