
      
AR<-function(score_wiele, def, plot=FALSE, return.table=FALSE, 
									sort.order=NULL)
{
	
	if (is.null(score_wiele))
		stop("Zmienna 'score_wiele' musi by� r�na od NULL!");
	if (is.null(def))
		stop("Zmienna 'def' musi by� r�na od NULL!");
	                                          
	if (is.vector(score_wiele))	
		#Je�li jest wektorem, to pobieram jego nazw� i robi�  data.frame
		score_wiele<-do.call('data.frame', list(substitute(score_wiele)))
	else
		score_wiele<-as.data.frame(score_wiele);

	#sprawdzam, czy def jest z zakresu [0,1]
	if (min(def)<0 || max(def)>1) 
		stop("Zmienna 'def' musi by� z zakresu [0,1].");
		
	if (!is.null(sort.order))
		for (i in 1:length(score_wiele))
			sort.order[i]<-match.arg(sort.order[i], c("br","score"));
	
	ile_scorow<-ncol(score_wiele);
	nazwa<-ARt<-rep(0,ile_scorow);

	wynik<-list();

	def_all<-sum(def);
	obs_all<-length(def);
	good_all<-obs_all-def_all;


	if (plot){
		plot(c(0,1), c(0,1), type="l", lty=1, col=1, xlab="", ylab="");
		lines(c(0,def_all/obs_all,1),c(0,1,1), col=1);
	}
	for (i in 1:ile_scorow)
	{

		#*** wstepne przygotowania ***
		#kolej<-order(score_wiele[,i]);
		#dane<-data.frame(score=score_wiele[,i], def)[kolej,];
		#dane<-data.frame(score=score_wiele[,i], def);

		#agreguj� do poziomu unikalnych wartosci score
		bad<-tapply(def,score_wiele[,i],sum);
		obs<-as.vector(table(score_wiele[,i]));	
		br=bad/obs;
		
		if (!is.null(sort.order) && sort.order[i]=="br")
		{
			k<-order(br, decreasing =TRUE);
			bad<-bad[k];
			obs<-obs[k];
			br<-br[k];
		}
		
		pct_all<-obs/obs_all;
		pct_bad<-bad/def_all;
		pct_good<-(obs-bad)/good_all;
		
		cum_pct_obs<-cumsum(pct_all);
		cum_pct_bad<-cumsum(pct_bad);
		cum_pct_good<-cumsum(pct_good);
										 
		#bior� poprzedni element
		cum_pct_bad_prev<-lag(cum_pct_bad,1,fill=0);
		cum_pct_obs_prev<-lag(cum_pct_obs,1,fill=0);

		#licze kawalki powierzchni
		AUC_part<-(cum_pct_obs-cum_pct_obs_prev)*(cum_pct_bad+cum_pct_bad_prev)/2;

		#sumuje cala powierzchnie
		AUC<-sum(AUC_part);
	
		#uwzgledniam bad rate w probce
		ARt[i]<-(2*AUC-1)/(1-def_all/obs_all);
		KS<-max(abs(cum_pct_bad-cum_pct_good));
		IV<-sum((pct_good-pct_bad)*log(pct_good/pct_bad));
		
		if (return.table==TRUE)
			wynik$nowy<-list(table=data.frame(bad, obs,pct_all, 
						 pct_bad, pct_good, cum_pct_obs, cum_pct_bad, cum_pct_good,
						 br), stats=c(bad=def_all, good=good_all, obs=obs_all, br=def_all/obs_all, AR=ARt[i], KS=KS, IV=IV))
	 	else
			wynik$nowy<-list(stats=c(bad=def_all, good=good_all, obs=obs_all, br=def_all/obs_all, AR=ARt[i], KS=KS, IV=IV));
	 	

		names(wynik)[match("nowy",names(wynik))]=names(score_wiele)[i];
		if (plot)
			lines(c(0,cum_pct_obs), c(0,cum_pct_bad), type="l", lty=1, col=i+1);
	}
	kolej<-order(ARt);
	ARt=round(ARt*100,2);
	if (plot)
		legend(1,0,paste(names(score_wiele)[kolej], " (", ARt[kolej], "%)", sep="" ),lty=1, 
			 col=kolej+1, cex=0.8, xjust=1, yjust=0 );

	return(wynik);
}

#TODO: doda� do dokumentacji no.bads.action
buckety_br<-function(score, default, n, method=c("eq_length", "eq_count"), no.bads.action=c("none","combine"))
{
#	TODO - domy�lna warto�� method
	method<-match.arg(method);

	dane<-as.data.frame(cbind(score, default));
	dane<-dane[order(dane$score),];

	#dolny kraniec bucketa (wartosc score)
	od=c(1:n);
	#gorny kranieb bucketa (wartosc score)
	do=c(1:n);
	
	if (method=="eq_length")
	{	
		dane$przedzial<-cut(dane$score,n);
		przedzial<-levels(cut(dane$score,n));

		for (i in 1:length(przedzial)) 
		{

			od[i]=strsplit(przedzial[i], split=",")[[1]][1];
			od[i]=substr(od[i],2,nchar(od[i]));

			do[i]=strsplit(przedzial[i], split=",")[[1]][2];
			do[i]=substr(do[i],1,nchar(do[i])-1);
		}
		od<-as.numeric(od);
		do<-as.numeric(do);
	}
	else
	{

		perc<-1:(n+1);

		#wyznaczam krance przedzialow
		for (i in 0:n)
			perc[i+1]<-as.vector(quantile(dane$score, prob=i/n));
		granice<-unique(perc);
		granice<-granice[order(granice)];

		#oznaczam, do ktorego przedzialu nalezy dana obserwacja
		dane$przedzial<-findInterval(dane$score, granice, rightmost.closed = TRUE, all.inside = TRUE);
		
		#i licze potrzebne rzeczy
		od<-granice[1:(length(granice)-1)];
		do<-granice[2:length(granice)];		

	}

	srodek<-as.vector(tapply(dane$score, dane$przedzial, median));
	#usuwam buckety, gdzie nie ma obserwacji
	zostaw<-!is.na(srodek);
	srodek<-srodek[zostaw];

	mean<-as.vector(tapply(dane$score, dane$przedzial, mean))[zostaw];
	n_obs<- as.vector(tapply(dane$score, dane$przedzial, length))[zostaw];
	n_default<- as.vector(tapply(dane$default, dane$przedzial, sum))[zostaw];
	br<- as.vector(tapply(dane$default, dane$przedzial, mean))[zostaw];
	logit<-log(br/(1-br));
	probit<-qnorm(br);

	do_wagi<-n_default;
	do_wagi[do_wagi==0]<-0.5;
	do_wagi[do_wagi==n_obs]<-n_obs[do_wagi==n_obs]-0.5;
	waga<-n_obs/((do_wagi)/(n_obs)*(1-(do_wagi)/(n_obs)));
	as.data.frame(cbind( nr=(1:length(od))[zostaw],  od[zostaw], srodek, mean, do[zostaw], n_default, n_obs, br, logit, probit, var=br*(1-br)/n_obs, waga))
}

#TODO: doda� do dokumentacji no.bads.action
buckety_br_dev<-function(x, y, n, method=c("eq_length", "eq_count"), one.value.action=c("none","combine"))
{
#	TODO - domy�lna warto�� method
	method<-match.arg(method);

	#dolny kraniec bucketa (wartosc x)
	od=c(1:n);
	#gorny kranieb bucketa (wartosc x)
	do=c(1:n);
	
	if (method=="eq_length")
		granice<-seq(min(x),max(x),length.out=n+1)
	else
		granice<-as.vector(unique(quantile(x, prob=0:n/n, type=1)));

	#oznaczam, do ktorego przedzialu nalezy dana obserwacja
	przedzial<-findInterval(x, granice, rightmost.closed = TRUE, all.inside = TRUE);
	
	#i licze potrzebne rzeczy
	od<-granice[1:(length(granice)-1)];
	do<-granice[2:length(granice)];		

	srodek<-as.vector(tapply(x, przedzial, median));

	mean<-as.vector(tapply(x, przedzial, mean));
	n_obs<- as.vector(tapply(x, przedzial, length));
	n_default<- as.vector(tapply(y, przedzial, sum));
	br<- as.vector(tapply(y, przedzial, mean));
	logit<-log(br/(1-br));
	probit<-qnorm(br);

	zostaw<-unique(przedzial);
	
	as.data.frame(cbind(nr=zostaw,  od=od[zostaw], do=do[zostaw], 
								srodek, mean,  n_default, n_obs, br, logit, probit, var=br*(1-br)/n_obs))
}


	if (!is.null(breaks)) {
	
		granice<-sort(breaks);
		od<-breaks[1:length(breaks)-1];
		do<-breaks[2:length(breaks)];
		#oznaczam, do ktorego przedzialu nalezy dana obserwacja
		by<-findInterval(score, granice, rightmost.closed = TRUE, all.inside = TRUE);
		
		#usuwam puste przedzia�y
		od<-od[unique(by)];
		do<-do[unique(by)];
	}
	
	if (is.numeric(score)) {	
		median<-as.vector(tapply(score, by, median));
		mean<-as.vector(tapply(score, by, mean));
	}
	else
		by=score;


buckety_stat<-function(bucket, default, total=TRUE)
{
		
#	dane<-as.data.frame(cbind(score, default));
		
	obs<- table(bucket);
	obs_all<-sum(obs);
	bad<- as.vector(tapply(default, bucket, sum));
	bad_all<-sum(bad);
	br<- as.vector(tapply(default, bucket, mean));
	logit<-log(br/(1-br));                       
	probit<-qnorm(br);

	do_wagi<-bad;
	do_wagi[do_wagi==0]<-0.5;
	do_wagi[do_wagi==obs]<-obs[do_wagi==obs]-0.5;
	waga<-obs/((do_wagi)/(obs)*(1-(do_wagi)/(obs)));
	
	pct_good=(obs-bad)/(obs_all-bad_all);
	pct_bad=bad/bad_all;
	woe=log(pct_good/pct_bad)
	
	wynik<-as.data.frame(cbind( nr=1:length(obs),  
											 n_good=(obs-bad), pct_good,
									     n_bad=bad, pct_bad, 
											 n_obs=obs, pct_obs=obs/obs_all,
											 gb_odds=(obs-bad)/bad,
										   br, woe, logit, probit, var=br*(1-br)/obs, waga))
										   
  rownames(wynik)<-sort(unique(bucket));
  
	if (total)
			wynik<-rbind(wynik, TOTAL=c(length(obs)+1, obs_all-bad_all, 1, bad_all, 1, obs_all,1, 
														(obs_all-bad_all)/bad_all, bad_all/obs_all, 0, NA, NA, NA, NA));

	return(wynik);
}

drzewo<-function(score, def, freq=NULL, wytnij=0.01, min_split=30, min_bucket=10, max_gleb=4, n_buckets=20, plot=c(TRUE,FALSE))
{

	#musze teraz wywolac buckety_br, bo pozniej agreguje wektory
	#do jednego scoru i wykorzystuje freq, a buckety_br musi miec
	#jeden rekord=jedna obserwacja
	#if (plot)
	#	b<-buckety_br(score , def, n_buckets, method="eq_lengt");

	k<-order(score);
	score<-score[k];
	def<-def[k];

	if (is.null(freq))
		freq<-rep(1,length(score))
	else
	{
		stop("poki co nie obslugiwane freq inne od NULL");
		freq<-freq[k];
	}
	if (wytnij>0)
	{	
		usun<-usun_konce(score, prob=wytnij);
		score<-score[-usun];
		def<-def[-usun];
		freq<-freq[-usun];
	}
	
	def_a<-tapply(def,score,sum);
	freq_a<-tapply(freq, score, sum);
	score_a<-unique(score);
	
	#vec_stats(score_a);
	w<-drzewo_podzial(score_a, def_a, 1, min(score), max(score), freq_a, 0, min_split, min_bucket, max_gleb);
	
	#wybieram liscie
	w<-w[is.na(w$poprawa),];

	#i robie dla nich statystyki
	bucket<-buckety_br(score, def, w$od, w$do);
	bucket$fitted<-bucket$br;

	#	----- rysowanie -----
	if (plot)
	{

		plot(bucket$srodek, bucket$br, xlab="", ylab="");
		for (i in 1:length(w$od))
			lines(c(bucket$od[i], bucket$do[i]), c(bucket$fitted[i],bucket$fitted[i]), col="blue");
	}

	bucket
}

drzewo_podzial<-function(score, def, nr_wezla, od, do, freq, glebokosc, min_split=200, min_bucket=100, max_gleb=3)
{
	#print("#####################");
	#print(nr_wezla);print(score);print(def);print(od);print(do);print(freq);print(glebokosc);
	all_obs<-sum(freq);
	all_bad<-sum(def);
	br_akt<-all_bad/all_obs;
	gini_akt<-br_akt*(1-br_akt)*all_obs;
	wezel<-data.frame(nr_wezla, rodzic=floor(nr_wezla/2), od, do, n_obs=all_obs, n_bad=all_bad, br=br_akt, poprawa=NA, podzial=NA);
	
	wynik<-wezel;

	#jesli ilosc obserwacji jest wystarczajaca, aby zrobic podzial w wezle
	if (all_obs>min_split)
	{
		cum_bad_lewo<-cumsum(def);
		cum_obs_lewo<-cumsum(freq);

		cum_bad_prawo<-(all_bad-cum_bad_lewo);
		cum_obs_prawo<-(all_obs-cum_obs_lewo);

		br_lewo<-cum_bad_lewo/cum_obs_lewo;
		br_prawo<-cum_bad_prawo/cum_obs_prawo;

		gini_lewo<-br_lewo*(1-br_lewo)*cum_obs_lewo;
		gini_prawo<-br_prawo*(1-br_prawo)*cum_obs_prawo;
	
		gini_roz<-gini_akt-(gini_prawo+gini_lewo);
		#print("gini");print(gini_akt);print(gini_prawo);print(gini_lewo)
	
		#zostawiam podzialy, dla ktorych spelnione sa wymogi na ilosc
		#obserwacji w wynikowych lisciach
		zostaw<-(cum_obs_lewo>min_bucket)&(cum_obs_prawo>min_bucket);
		gini_roz[!zostaw]<-NA;

		#nr podzialu maksymalizujacego roznice gini
		nr<-which.max(gini_roz);
		if (length(nr)>0 & glebokosc<max_gleb)
		{
			wezel$poprawa<-gini_roz[nr];
			wezel$podzial<-(score[nr]+score[nr+1])/2;
			l<-length(score);
			wl<-drzewo_podzial(score[1:nr], def[1:nr], nr_wezla*2, od, wezel$podzial, freq[1:nr], glebokosc+1, min_split, min_bucket, max_gleb);
			wr<-drzewo_podzial(score[(nr+1):l], def[(nr+1):l], nr_wezla*2+1, wezel$podzial, do, freq[(nr+1):l], glebokosc+1, min_split, min_bucket, max_gleb);
			wynik<-rbind(wezel,wl,wr);
		}
	}
	
	wynik
}


informacje<-function(score, default, buckets=20, span=0.8, main="", hist_col="blue", type="br", method_bucket="eq_length")
{	
	#def_par=par(no.readonly=TRUE);

	par(mar=c(7,4,4,5) + 0.1); # Leave space for z axis
	
	h<-hist(score, plot=FALSE);
#	w<-wygladz(score, default, buckets=buckets, span=span, type=type,  plot=FALSE, method_bucket=method_bucket);
	local<-locfit(default~lp(score, nn=span), family="binomial", link="logit");
	br2<-predict(local,newdata=h$mid);
	cut_<-cut(score, breaks=h$breaks);
	br<-tapply(default, cut_, mean);
	XRange <- range( c(h[["break"]], h$mid) );
	
	plot(h, col=hist_col ,axes=FALSE, ann=FALSE, ylab="", main=main, xlim=XRange);

	# Now draw x axis 
	par(new=T);
	axis(1, col = "black") 

	# Now draw y axis 
	par(new=T);
	axis(2, col = hist_col) 

	# Now draw y axis label
	par(new=T);
	mtext(side = 2, text = "Frequency", line = 3, col="black") 

	# Use axTicks() to get default tick locations
	#par(new=T);
	#at = axTicks(2)
	#mtext(side = 2, text = at, at = at, col = "black", line = 1)

	par(new=T)
	YRange <- range( c(br, br2) );
	plot(h$mid, br, type="p", axes=F, xlab="", ylab="", bty="n", pch=16, xlim=XRange, ylim=YRange);

	par(new=T)
	plot(h$mid, br2, type="l", axes=F, xlab="", ylab="", bty="n", xlim=XRange, ylim=YRange);

	par(new=T);
	axis(4, at=pretty(YRange))

	par(new=T);
	mtext(type, 4, 3) 

	par(new=T);
	AR_value<-AR2(score, default, plot=F)
	mtext( paste("AR = ", round(AR_value[[1]]$AR[1]*100,2), "%;   BR = ",round(mean(default)*100,digits=2),"%" ), 1, 5, col="darkgreen");

#	par(def_par);
}


lag<-function(x, d, fill=NA)
{
	c(rep(fill,d),x)[1:length(x)]
};


plot_AR<-function(ar, plot_type=c("ROC", "CAP"))
{
	plot_type<-match.arg(plot_type);

	plot(c(0,1), c(0,1), type="l", lty=1, col=1, xlab="", ylab="");
	if (plot_type=="CAP"){
		br<-ar[[1]]$br[ dim(ar[[1]])[1] ];
		lines(c(0,br,1),c(0,1,1), col=1);
	}
	AR<-rep(-1,length(ar));
	for (i in 1:length(ar))
	{
		if (plot_type=="CAP")
			lines(c(0,ar[[i]]$pct_all), c(0,ar[[i]]$pct_bad), type="l", lty=1, col=i+1)
		else
			lines(c(0,ar[[i]]$pct_good), c(0,ar[[i]]$pct_bad), type="l", lty=1, col=i+1);
		AR[i]<-ar[[i]]$AR[1];
	}
	kolej<-order(AR);
	AR<-round(AR*100,2);

	legend(1,0,paste(names(ar)[kolej], " (", AR[kolej], "%)", sep="" ),lty=1, 
		 col=kolej+1, cex=0.8, xjust=1, yjust=0 );
}

plot_AR_dev<-function(ar, plot_type=c("ROC", "CAP"),...)
{
	plot_type<-match.arg(plot_type);

	plot(c(0,1), c(0,1), type="l", lty=1, col=1, xlab="", ylab="",...);
	if (plot_type=="CAP"){
		br<-ar[[1]]$stats["br"];
		lines(c(0,br,1),c(0,1,1), col=1);
	}
	AR<-rep(-1,length(ar));
	for (i in 1:length(ar))
	{
		if (plot_type=="CAP")
			lines(c(0,ar[[i]]$table$cum_pct_obs), c(0,ar[[i]]$table$cum_pct_bad), type="l", lty=1, col=i+1)
		else
			lines(c(0,ar[[i]]$table$cum_pct_good), c(0,ar[[i]]$table$cum_pct_bad), type="l", lty=1, col=i+1);
		AR[i]<-ar[[i]]$stats["AR"];
	}
	kolej<-order(AR);
	AR<-round(AR*100,2);

	legend(1,0,paste(names(ar)[kolej], " (", AR[kolej], "%)", sep="" ),lty=1, 
		 col=kolej+1, cex=0.8, xjust=1, yjust=0 );
}

przypisz<-function(x, bucket, interpol=FALSE)
{

	n<-dim(bucket)[1];

	{
		
		if (interpol)
		{
			#obcinam zakresy do wartosci srodkow krancowych przedzialow
			x[x<min(bucket$srodek)]<-min(bucket$srodek);
			x[x>max(bucket$srodek)]<-max(bucket$srodek);

			przedzial<-findInterval(x, bucket$srodek, rightmost.closed = TRUE, all.inside = TRUE);

			od<-bucket$srodek[przedzial];
			do<-bucket$srodek[przedzial+1];
			wynik<-(x-od)/(do-od)*bucket$fitted[przedzial+1]+(do-x)/(do-od)*bucket$fitted[przedzial];
		}
		else
		{
			granice=unique(c(bucket$od, bucket$do));
			przedzial<-findInterval(x, granice, rightmost.closed = TRUE, all.inside = TRUE);
			wynik<-bucket$fitted[przedzial];
		}
	}	
	wynik
}


reg_nieparam_old<-function(score, default, buckets=100, wytnij=0.01, span=0.7, degree=2, plot=TRUE, new=TRUE, col_points="black", col_line="darkblue")
{

	dane<-data.frame(score,default)
	if (wytnij>0)
		dane<-dane[-usun_konce(dane$score, prob=wytnij),];
		
	bucket<-buckety_br(dane$score , dane$default, buckets, method="eq_count");
	l<- locfit(default ~ lp(score, nn=span), family="binomial", link="logit", data=dane) 
	b2<-predict(l, newdata=bucket$srodek);
	bucket2<-cbind(bucket, fitted=b2);
	
	if (plot){
		if (new==TRUE)
			plot(bucket2$srodek, bucket2$br, xlab="", ylab="", col=col_points)
		else
			points(bucket2$srodek, bucket2$br, xlab="", ylab="", col=col_points);
		lines(bucket2$srodek, bucket2$fitted,  col=col_line);
	}
	bucket2
}		


reg_nieparam<-function(score, default, buckets=100, wytnij=0.01, span=0.7, degree=2, plot=TRUE, new=TRUE, col_points="black", col_line="darkblue")
{

	dane<-data.frame(score,default)
	if (wytnij>0)
		dane<-dane[-usun_konce(dane$score, prob=wytnij),];
		
	bucket<-buckety_br(dane$score , dane$default, buckets, method="eq_count");
	if (length(unique(default))==2)
		l<- locfit(default ~ lp(score, nn=span), family="binomial", link="logit", data=dane)
	else
		l<- locfit(default ~ lp(score, nn=span), data=dane) 

	b2<-predict(l, newdata=bucket$srodek);
	bucket2<-cbind(bucket, fitted=b2);
	
	if (plot){
		if (new==TRUE)
			plot(bucket2$srodek, bucket2$br, xlab="", ylab="", col=col_points)
		else
			points(bucket2$srodek, bucket2$br, xlab="", ylab="", col=col_points);
		lines(bucket2$srodek, bucket2$fitted,  col=col_line);
	}
	bucket2
}		

usun_konce<-function(score, prob=0.01)
{
	l=quantile(score, prob=prob);
	p=quantile(score, prob=(1-prob));
	
	#sprawdzam, w taki lewy sposob, czy zmienna nie jest ograniczona z dolu
	#z bledem +-1 obserwacja

	do_usuniecia<-rep(FALSE,times=length(score));
	if ( abs(length(score[score<=l])-length(score)*prob)<=1 )
			do_usuniecia<-(score<=l);

	if ( abs(length(score[score>=p])-length(score)*prob)<=1 )
		do_usuniecia<-do_usuniecia | (score>=p);

	c(1:length(score))[do_usuniecia]
}


vec_stats<-function(x)
{
	print("Pierwsze 5:");
	print(x[1:5]);
	
	print(table(!is.na(x)));
	
	print(summary(x));
	srednia<-mean(x, na.rm=T);
	ile<-length(x);
	print(paste("srednia: ",srednia, " dlugosc: ",ile));

	print("Ostatnie 5:");
	print(x[(length(x)-5):length(x)]);

	par(mfrow=c(1,2));
	hist(x);
	hist(x[quantile(x,prob=0.03, na.rm=T)<x & x<quantile(x,prob=0.97, na.rm=T)]);
	par(mfrow=c(1,1));
}

wygladz<-function(score, default, buckets=50, span=0.5, type="logit", plot=TRUE, method_bucket="eq_count")
{
	
	if (buckets>length(score))
		print("ERROR: liczba bucketow wieksza, niz liczba obserwacji!");
	dane<-as.data.frame(cbind(score, default));
	dane<-dane[order(dane$score),];

	bucket<-buckety_br(dane$score, dane$default, buckets, method=method_bucket);
	
	if (type=="logit") 
		wartosci <- bucket$logit
	else if (type=="probit")
		wartosci <- bucket$probit
	else if (type == "br")
		wartosci=bucket$br
	else print("ERROR: blednie podana wartosc zmiennej 'type'");

	#usuwam nieskonczonosci
	zostaw=abs(wartosci) != Inf;
	wartosci=wartosci[zostaw];

      #b2 <- loess(wartosci ~ bucket$srodek[zostaw], span=span);
	local<-locfit(default~lp(score, nn=span), family="binomial", link="logit");
	b2<-predict(local,newdata=bucket$srodek[zostaw]);
	if (plot)
	{
		plot(local);
		points(bucket$srodek[zostaw], wartosci);
	}
	wyn<-cbind(bucket$srodek[zostaw], wartosci, b2);
	colnames(wyn)<-c("srodek","br","fitted");
	as.data.frame(wyn)
}

